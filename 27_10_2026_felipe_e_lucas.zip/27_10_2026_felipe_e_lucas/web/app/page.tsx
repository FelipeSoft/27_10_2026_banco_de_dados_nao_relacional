"use client"

import { useEffect, useState } from "react";

interface Employer {
  _id: string;
  name: string;
  number: string;
  salary: string;
  position: string;
}

export default function Home() {
  const [employer, setEmployer] = useState({ number: "", name: "", salary: "", position: "" })
  const [employers, setEmployers] = useState([])

  const addEmployer = async () => {
    await fetch("http://localhost:4000/employers", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        number: employer.number,
        name: employer.name,
        salary: employer.salary,
        position: employer.position,
      })
    })
    renderEmployers()
  }

  const renderEmployers = async () => {
    const response = await fetch("http://localhost:4000/employers", {
      method: "GET"
    });
    const data = await response.json()
    setEmployers(data.employers);
  }

  useEffect(() => {
    renderEmployers()
  }, [])

  return (
    <main className="max-w-md p-4 mx-auto">
      <h1 className="text-xl font-semibold">Gerenciamento de Funcionários</h1>
      <form onSubmit={(e) => {
        e.preventDefault()
        addEmployer()
      }} className="mt-4 flex flex-col gap-4">
        <label className="flex flex-col">
          Matrícula
          <input
            value={employer.number}
            onChange={(e) => setEmployer((prev) => ({ ...prev, number: e.target.value }))}
            className="rounded-md py-2 px-4 border"></input>
        </label>
        <label className="flex flex-col">
          Nome
          <input
            value={employer.name}
            onChange={(e) => setEmployer((prev) => ({ ...prev, name: e.target.value }))}
            className="rounded-md py-2 px-4 border"></input>
        </label>
        <label className="flex flex-col">
          Salário
          <input
            value={employer.salary}
            onChange={(e) => setEmployer((prev) => ({ ...prev, salary: e.target.value }))}
            type="number" className="rounded-md py-2 px-4 border"></input>
        </label>
        <label className="flex flex-col">
          Cargo
          <input
            value={employer.position}
            onChange={(e) => setEmployer((prev) => ({ ...prev, position: e.target.value }))}
            className="rounded-md py-2 px-4 border"></input>
        </label>
        <button type="submit" className="px-4 py-2 rounded-md bg-blue-500 w-full text-white hover:bg-blue-600 cursor-pointer transition-all">Adicionar Funcionário</button>
      </form>
      <h2 className="text-lg font-semibold mt-8">Listagem de Funcionários</h2>
      <ul className="flex flex-col gap-4 mt-4">
        {Array.isArray(employers) && employers.length > 0 && employers.map((employer: Employer, index: number) => (
          <li key={index} className="flex flex-col gap-2 border rounded-md bg-gray-100/50 p-4">
            <div>Matrícula: {employer.number}</div>
            <div>Nome: {employer.name}</div>
            <div>Salário: {employer.salary}</div>
            <div>Cargo: {employer.position}</div>
          </li>
        ))}
      </ul>
    </main>
  );
}
