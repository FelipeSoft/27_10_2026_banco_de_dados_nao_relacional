const express = require("express")
const cors = require("cors")
const mongoose = require("mongoose")
const Employer = require("./model.js")

mongoose.connect('mongodb://localhost:27017/27_10_2026_felipe_e_lucas')
    .then(() => console.log('Conectado ao MongoDB!'))
    .catch(err => console.error('Erro ao conectar:', err));

const app = express()
app.use(cors({
    origin: 'http://localhost:3000'
}))
app.use(express.json())

app.get("/employers", async (req, res) => {
    try {
        const employers = await Employer.find()
        return res.status(200).json({ employers })
    } catch (error) {
        return res.status(500).json({
            message: "Erro interno no servidor."
        })
    }
})

app.post("/employers", async (req, res) => {
    try {
        if (!req.body?.number || !req.body?.name || !req.body?.salary || !req.body?.position) {
            return res.status(400).json({
                message: "Campos faltantes para criação do funcionário."
            })
        }
        const employer = new Employer({
            name: req.body.name,
            number: req.body.number,
            salary: req.body.salary,
            position: req.body.position,
        })
        await employer.save()
        return res.status(201).json({
            message: "Funcionário criado com sucesso."
        })
    } catch (error) {
        return res.status(500).json({
            message: "Erro interno no servidor."
        })
    }
})

app.listen(4000)