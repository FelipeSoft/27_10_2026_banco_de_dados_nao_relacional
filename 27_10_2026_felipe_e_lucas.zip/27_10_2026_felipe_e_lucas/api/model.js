const mongoose = require("mongoose")

const employerSchema = new mongoose.Schema({
    number: {
        type: String,
        required: true,
    },
    name: {
        type: String,
        required: true,
    },
    salary: {
        type: String,
        required: true,
    },
    position: {
        type: String,
        required: true,
    },
});

module.exports = mongoose.model('Employer', employerSchema);